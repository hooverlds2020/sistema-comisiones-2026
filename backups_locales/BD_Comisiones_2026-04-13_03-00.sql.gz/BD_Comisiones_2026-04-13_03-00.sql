--
-- PostgreSQL database dump
--

\restrict e1w05nY39ZXUbVnakIjJYtPoCwz3gnyQW3AyErGivYbfvXnaJjFQUUYTT1mJs76

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: autoridades; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.autoridades (
    id integer NOT NULL,
    rol character varying(50),
    nombre character varying(200),
    cargo character varying(150),
    activo boolean DEFAULT true
);


ALTER TABLE public.autoridades OWNER TO admin;

--
-- Name: autoridades_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.autoridades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.autoridades_id_seq OWNER TO admin;

--
-- Name: autoridades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.autoridades_id_seq OWNED BY public.autoridades.id;


--
-- Name: bitacora; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.bitacora (
    id integer NOT NULL,
    usuario character varying(100) NOT NULL,
    accion character varying(50) NOT NULL,
    folio character varying(50),
    detalles text,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bitacora OWNER TO admin;

--
-- Name: bitacora_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.bitacora_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bitacora_id_seq OWNER TO admin;

--
-- Name: bitacora_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.bitacora_id_seq OWNED BY public.bitacora.id;


--
-- Name: claves_presupuestales; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.claves_presupuestales (
    id integer NOT NULL,
    clave character varying(100) NOT NULL,
    descripcion text
);


ALTER TABLE public.claves_presupuestales OWNER TO admin;

--
-- Name: claves_presupuestales_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.claves_presupuestales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.claves_presupuestales_id_seq OWNER TO admin;

--
-- Name: claves_presupuestales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.claves_presupuestales_id_seq OWNED BY public.claves_presupuestales.id;


--
-- Name: claves_programaticas; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.claves_programaticas (
    id integer NOT NULL,
    clave character varying(100) NOT NULL,
    descripcion text
);


ALTER TABLE public.claves_programaticas OWNER TO admin;

--
-- Name: claves_programaticas_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.claves_programaticas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.claves_programaticas_id_seq OWNER TO admin;

--
-- Name: claves_programaticas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.claves_programaticas_id_seq OWNED BY public.claves_programaticas.id;


--
-- Name: ordenes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ordenes (
    id integer NOT NULL,
    comisionado character varying(255) NOT NULL,
    lugar character varying(255) NOT NULL,
    fecha_inicio date,
    fecha_fin date,
    estatus character varying(50) DEFAULT 'Borrador'::character varying,
    rfc character varying(20),
    categoria character varying(100),
    adscripcion character varying(100),
    motivo text,
    hora_salida time without time zone,
    hora_regreso time without time zone,
    medio_transporte character varying(50),
    vehiculo_marca character varying(50),
    vehiculo_modelo character varying(50),
    vehiculo_placas character varying(20),
    clave_programatica text,
    cuota_diaria text DEFAULT 0,
    importe_combustible numeric(10,2) DEFAULT 0,
    importe_pasajes numeric(10,2) DEFAULT 0,
    importe_viaticos numeric(10,2) DEFAULT 0,
    importe_otros numeric(10,2) DEFAULT 0,
    importe_total numeric(10,2) DEFAULT 0,
    importe_pasajes_aereos numeric(10,2) DEFAULT 0,
    importe_congresos numeric(10,2) DEFAULT 0,
    tipo_comision character varying(50) DEFAULT 'Nacional'::character varying,
    fecha_elaboracion date DEFAULT CURRENT_DATE,
    numero_folio integer,
    anio_folio integer,
    informe_actividades text,
    es_fechas_multiples boolean DEFAULT false,
    periodo_texto text,
    dias_salida text,
    dias_regreso text
);


ALTER TABLE public.ordenes OWNER TO admin;

--
-- Name: ordenes_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ordenes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordenes_id_seq OWNER TO admin;

--
-- Name: ordenes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ordenes_id_seq OWNED BY public.ordenes.id;


--
-- Name: personal; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.personal (
    id integer NOT NULL,
    nombre character varying(200),
    rfc character varying(50),
    categoria character varying(150),
    adscripcion character varying(150)
);


ALTER TABLE public.personal OWNER TO admin;

--
-- Name: personal_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.personal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_id_seq OWNER TO admin;

--
-- Name: personal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.personal_id_seq OWNED BY public.personal.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    nombre character varying(100) NOT NULL,
    rol character varying(50) NOT NULL,
    activo boolean DEFAULT true
);


ALTER TABLE public.usuarios OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: vehiculos; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.vehiculos (
    id integer NOT NULL,
    marca character varying(100),
    modelo character varying(100),
    placas character varying(50)
);


ALTER TABLE public.vehiculos OWNER TO admin;

--
-- Name: vehiculos_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.vehiculos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehiculos_id_seq OWNER TO admin;

--
-- Name: vehiculos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.vehiculos_id_seq OWNED BY public.vehiculos.id;


--
-- Name: autoridades id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.autoridades ALTER COLUMN id SET DEFAULT nextval('public.autoridades_id_seq'::regclass);


--
-- Name: bitacora id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.bitacora ALTER COLUMN id SET DEFAULT nextval('public.bitacora_id_seq'::regclass);


--
-- Name: claves_presupuestales id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.claves_presupuestales ALTER COLUMN id SET DEFAULT nextval('public.claves_presupuestales_id_seq'::regclass);


--
-- Name: claves_programaticas id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.claves_programaticas ALTER COLUMN id SET DEFAULT nextval('public.claves_programaticas_id_seq'::regclass);


--
-- Name: ordenes id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ordenes ALTER COLUMN id SET DEFAULT nextval('public.ordenes_id_seq'::regclass);


--
-- Name: personal id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.personal ALTER COLUMN id SET DEFAULT nextval('public.personal_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Name: vehiculos id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehiculos ALTER COLUMN id SET DEFAULT nextval('public.vehiculos_id_seq'::regclass);


--
-- Data for Name: autoridades; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.autoridades (id, rol, nombre, cargo, activo) FROM stdin;
1	DIRECTOR	DR. EMMANUEL NÁJERA DE LEÓN	DIRECTOR CESMECA-UNICACH	t
2	SECRETARIO	LIC. ENRIQUE PÉREZ LÓPEZ	SECRETARIO ACADÉMICO-UNICACH	t
3	RECTORA	ARQUEOL. JUANA DE DIOS LÓPEZ JIMÉNEZ	RECTORA	t
\.


--
-- Data for Name: bitacora; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.bitacora (id, usuario, accion, folio, detalles, fecha) FROM stdin;
1	admin	LOGIN	\N	Inicio de sesión	2026-03-25 16:46:45.595013
2	pballinas	LOGIN	\N	Inicio de sesión	2026-03-25 16:48:29.964406
3	admin	LOGIN	\N	Inicio de sesión	2026-03-25 17:04:25.801086
4	Sistema	CREAR	081/CESMECA/2026	Creada para C.P. PATRICIA BALLINAS SALAZAR	2026-03-25 17:05:33.337836
5	admin	LOGIN	\N	Inicio de sesión	2026-03-25 18:06:34.934278
6	pballinas	LOGIN	\N	Inicio de sesión	2026-03-25 19:45:18.032463
7	admin	LOGIN	\N	Inicio de sesión	2026-03-25 19:45:56.046279
8	pruiz	LOGIN	\N	Inicio de sesión	2026-03-25 22:37:00.994571
9	Patricia Ruiz	EDITAR	081/CESMECA/2026	Modificada por Patricia Ruiz	2026-03-25 22:37:23.513862
10	admin	LOGIN	\N	Inicio de sesión	2026-03-25 22:37:41.158608
11	admin	LOGIN	\N	Inicio de sesión	2026-03-27 07:56:23.486563
12	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 07:57:08.799217
13	admin	LOGIN	\N	Inicio de sesión	2026-03-27 08:36:06.579762
14	admin	LOGIN	\N	Inicio de sesión	2026-03-27 14:59:51.2423
15	Patricia Ballinas	CREAR	082/CESMECA/2026	Creada para LIC. JENNY ARACELI MOLINA GOMEZ	2026-03-27 15:56:11.616482
16	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 16:03:08.729305
17	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:04:44.57743
18	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:05:46.953746
19	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:06:30.661105
20	admin	LOGIN	\N	Inicio de sesión	2026-03-27 16:07:38.360703
21	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:16:58.776338
22	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 16:31:53.865048
23	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 16:37:05.572217
24	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:43:49.730678
25	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:44:21.243257
26	admin	LOGIN	\N	Inicio de sesión	2026-03-27 18:55:54.116286
27	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 18:57:36.764051
28	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 19:16:41.632068
29	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 20:25:55.625808
\.


--
-- Data for Name: claves_presupuestales; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.claves_presupuestales (id, clave, descripcion) FROM stdin;
1	26111	COMBUSTIBLE
2	37111	PASAJES NACIONALES AÉREOS
3	37211	PASAJES NACIONALES TERRESTRES
4	37511	VIÁTICOS NACIONALES
5	38301	CONGRESOS Y CONVENCIONES
6	39202	OTROS IMPUESTOS Y DERECHOS
\.


--
-- Data for Name: claves_programaticas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.claves_programaticas (id, clave, descripcion) FROM stdin;
1	4008000 (0121) 2.06.PRDI101.PYI001	Dependencia 4008000 - Fondo 0121
2	4008000 (0121) 2.06.PRDI1029.PYI029	Dependencia 4008000 - Fondo 0121
3	4008000 (0121) 2.06.PRDI1034.PYI034	Dependencia 4008000 - Fondo 0121
4	4008000 (0121) 2.06.PRDI202.PYI002	Dependencia 4008000 - Fondo 0121
5	4008000 (0121) 2.06.PRDI506.PYI006	Dependencia 4008000 - Fondo 0121
6	4008000 (0121) 2.06.PRDI614.PYI014	Dependencia 4008000 - Fondo 0121
\.


--
-- Data for Name: ordenes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ordenes (id, comisionado, lugar, fecha_inicio, fecha_fin, estatus, rfc, categoria, adscripcion, motivo, hora_salida, hora_regreso, medio_transporte, vehiculo_marca, vehiculo_modelo, vehiculo_placas, clave_programatica, cuota_diaria, importe_combustible, importe_pasajes, importe_viaticos, importe_otros, importe_total, importe_pasajes_aereos, importe_congresos, tipo_comision, fecha_elaboracion, numero_folio, anio_folio, informe_actividades, es_fechas_multiples, periodo_texto, dias_salida, dias_regreso) FROM stdin;
6	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-02-25	2026-02-25	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	08:00:00	16:00:00	Terrestre	\N	\N	\N	\N	1 x $900.00 = $900.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-03-25	6	2026	\N	f	\N	\N	\N
2	C.P. PATRICIA BALLINAS SALAZAR	Ciudad de México	2026-02-23	2026-02-27	Borrador	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA	Viajar a la Ciudad de Tuxtla Gutiérrez para realizar seguimiento Institucional del CESMECA, en Rectoría, Secretarías y\nDepartamentos de la UNICACH. El importe será con cargo al POA 2025, del proyecto denominado: Programa para fortalecer la gestión administrativa de las unidades académicas y administrativas, Programa Institucional Consolidación del Posgrado y Programa Institucional de Divulgación, Vinculación y Servicios Universitarios.	08:00:00	16:00:00	Aéreo	\N	\N	\N	4008000 (0121) 2.06.PRDI101.PYI001	\N	0.00	1000.00	6000.00	0.00	16000.00	6000.00	3000.00	Internacional	2026-02-20	2	2026	\N	f	\N	\N	\N
4	DR. EMMANUEL NÁJERA DE LEÓN	Francia	2026-02-23	2026-02-27	Borrador	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA	Viajar a la Ciudad de Tuxtla Gutiérrez para realizar seguimiento Institucional del CESMECA, en Rectoría, Secretarías y Departamentos de la UNICACH. El importe será con cargo al POA 2025, del proyecto denominado: Programa para fortalecer la gestión administrativa de las unidades académicas y administrativas, Programa Institucional Consolidación del Posgrado y Programa Institucional de Divulgación, Vinculación y Servicios Universitarios.	08:00:00	23:00:00	Aéreo	\N	\N	\N	4008000 (0121) 2.06.PRDI202.PYI002	\N	0.00	0.00	20000.00	5000.00	55000.00	20000.00	10000.00	Internacional	2026-02-20	4	2026	\N	f	\N	\N	\N
20	LIC. JENNY ARACELI MOLINA GOMEZ	Tuxtla Gutiérrez	2026-03-27	2026-03-27	Borrador	MOGJ801228AU0	SECRETARIO ADMINISTRATIVO DE INSTITUTO "A"	CESMECA	Para realizar tramites administrativos y entrega de valija en Rectoría, Ciudad Universitaria y en CAMPUS, de la UNICACH. con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	\N	½ x $1,510.16 = $1,510.16	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-02-25	82	2026	\N	f			
1	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas.	2026-02-20	2026-02-20	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	Viajar a la Ciudad de Tuxtla Gutiérrez para realizar seguimiento Institucional del CESMECA, en Rectoría, Secretarías y Departamentos de la UNICACH. El importe será con cargo al POA 2025, del proyecto denominado: Programa para fortalecer la gestión administrativa de las unidades académicas y administrativas, Programa Institucional Consolidación del posgrado y Programa Institucional de Divulgación, Vinculación y Servicios Universitarios.	08:00:00	16:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008000 (0121) 2.06.PRDI101.PYI001	\N	1000.00	0.00	450.00	200.00	1650.00	0.00	0.00	Nacional	2026-02-20	1	2026	\N	f	\N	\N	\N
7	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-02-26	2026-02-26	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	08:00:00	16:00:00	Terrestre	\N	\N	\N	\N	1 x $900.00 = $900.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-02-24	7	2026	\N	f	\N	\N	\N
3	C. DORA JUVENALIA GORDILLO ESTRADA	Tuxtla Gutiérrez, Chiapas.	2026-02-27	2026-02-27	Borrador	GOED721218S25	TECNICO ESPECIALIZADO "C"	CESMECA	Viajar a la Ciudad de Tuxtla Gutiérrez, para asistir a una reunión al Consejo Universitario, en las instalaciones de Ciudad Universitaria. El importe será con cargo al POA 2018, del proyecto denominado: Programa para fortalecer la gestión administrativa de las unidades académicas.	08:00:00	16:00:00	Terrestre	\N	\N	\N	4008000 (0121) 2.06.PRDI614.PYI014	\N	0.00	140.00	450.00	0.00	590.00	0.00	0.00	Nacional	2026-02-20	3	2026	\N	f	\N	\N	\N
5	C.P. PATRICIA RUIZ PÉREZ	Tuxtla Gutiérrez, Chiapas	2026-02-25	2026-02-25	Borrador	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA	xxxxxxxxxxxxxxxxxxxxxxxxxx	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI101.PYI001, 4008000 (0121) 2.06.PRDI614.PYI014	1 x $450.00\n½ x $225.00 = $675.00	1000.00	0.00	450.00	200.00	1650.00	0.00	0.00	Nacional	2026-02-24	5	2026	\N	f	\N	\N	\N
8	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-02-27	2026-02-27	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1034.PYI034	1 x $900.00 = $900.00	1000.00	0.00	450.00	200.00	1650.00	0.00	0.00	Nacional	2026-02-25	8	2026	\N	f	\N	\N	\N
9	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-03-04	2026-03-04	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1034.PYI034	1 x $900.00 = $900.00	2000.00	0.00	450.00	200.00	2650.00	0.00	0.00	Nacional	2026-03-03	9	2026	\N	f	\N	\N	\N
10	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-03-12	2026-03-12	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029, 4008000 (0121) 2.06.PRDI202.PYI002	1 x $900.00 = $900.00	2000.00	0.00	450.00	200.00	2650.00	0.00	0.00	Nacional	2026-03-12	10	2026	\N	f	\N	\N	\N
12	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez Chiapas	\N	\N	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	viajar a tuxtla	\N	\N	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI101.PYI001	\N	0.00	0.00	0.00	0.00	50.00	0.00	50.00	Nacional	2026-03-18	68	2026	\N	t	11, 18, 19 de febrero 	11 de febrero de 2026\n18 de febrero de 2026\n19 de febrero de 2026	11 de febrero de 2026\n18 de febrero de 2026\n19 de febrero de 2026
14	C.P. PATRICIA RUIZ PÉREZ	Tuxtla Gutiérrez Chiapas	2026-04-14	2026-04-14	Borrador	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria y Rectoría de la UNICACH, para realizar trámites administrativos y la entrega de valija	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	800.00	0.00	300.00	200.00	1300.00	0.00	0.00	Nacional	2026-03-24	77	2026	\N	f			
13	MTRA. YESENIA LÓPEZ CRUZ	Tuxtla Gutiérrez, Chiapas	2026-03-25	2026-03-25	Borrador	LOCY871111RE3	SECRETARIA ACADEMICA DE INSTITUTO "B"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas,  con el objetivo de asistir a la conferencia  Igualdad y Equidad de género  que se llevara a  cabo el 25 de marzo del presente  año a las 10 :00 horas, en la Sala de Lectura  Informal del Centro Universitario  de Información y Documentación de C.U de la UNICACH. 	08:00:00	16:00:00	Terrestre	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-03-20	76	2026	\N	f			
11	DR. CARLOS DE JESÚS GÓMEZ ABARCA	CIUDAD DE MÉXICO	2026-03-04	2026-03-08	Borrador	GOAC840102PJ7	PROFESOR INVESTIGADOR DE TIEMPO COMPLETO TITULAR “A”	CESMECA	Viajar a la Ciudad de México, para asistir al Coloquio “América Central hoy. Autoritarismos, violencias y exilios” en la Sala 2 del Auditorio Pablo González Casanova, Instituto de Investigaciones Sociales, UNAM, Ciudad Universitaria. El importe será con cargo al POA 2026.	\N	\N	Aéreo	\N	\N	\N	4008000 (0121) 2.06.PRDI614.PYI014	4 x $5,393.44\n½ x $2,804.59 = $24,378.35	0.00	0.00	1791.11	0.00	5420.11	3629.00	0.00	Nacional	2026-03-02	67	2026	\N	f	\N	\N	\N
15	C.P. PATRICIA RUIZ PÉREZ	Tuxtla Gutiérrez Chiapas	2026-04-14	2026-04-14	Borrador	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria y Rectoría de la UNICACH, para realizar trámites administrativos y la entrega de valija. El importe será con cargo al POA  2026.\n	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	800.00	0.00	300.00	200.00	1300.00	0.00	0.00	Nacional	2026-03-24	78	2026	\N	f			
16	C.P. PATRICIA BALLINAS SALAZAR	Tuxtla Gutiérrez Chiapas	2026-04-17	2026-04-17	Borrador	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria de la UNICACH y Rectoría de la UNICACH, para realizar tramites administrativos  y entrega de valija. El importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	800.00	0.00	300.00	200.00	1300.00	0.00	0.00	Nacional	2026-03-24	79	2026	\N	f			
18	LIC. EGNER VAZQUEZ LÓPEZ	Tuxtla Gutiérrez, Chiapas	2026-03-25	2026-03-25	Borrador	VALE870125AI7	TECNICO ACADEMICO ASOCIADO "C"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas, para la presentación de las Políticas y Calendario de Actividades para la\n Integración de Plantillas Pregrado y Posgrado, la cual se llevará a cabo el día 25 de marzo del año en curso a las 13:00 horas  en la Sala  de lectura informal (sala verde ) del Centro Universitario  de informacion  y documentacion  de C.U de la UNICACH.\n.	11:30:00	17:00:00	Terrestre	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-03-24	80	2026	\N	f			
19	C.P. PATRICIA BALLINAS SALAZAR	Tuxtla Gutiérrez Chiapas	2026-04-21	2026-04-21	Borrador	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria y Rectoría de la UNICACH, para realizar trámites administrativos y la entrega de valija. \nEl importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	800.00	0.00	300.00	200.00	1300.00	0.00	0.00	Nacional	2026-03-25	81	2026	\N	f			
\.


--
-- Data for Name: personal; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.personal (id, nombre, rfc, categoria, adscripcion) FROM stdin;
1	MTRA. NORMA GUADALUPE PÉREZ LÓPEZ	PELN800901569	COORDINADOR ACADÉMICO "B"	CESMECA
2	MTRA. GABRIELA CARTAGENA LÓPEZ	CAL880703	COORDINADOR ACADÉMICO "C"	CESMECA
3	LIC. JENNY ARACELI MOLINA GOMEZ	MOGJ801228AU0	SECRETARIO ADMINISTRATIVO DE INSTITUTO "A"	CESMECA
4	C.P. YENNY REYES ROQUE	RERY8005134G0	JEFE DE OFICINA "A"	CESMECA
5	MTRA. YESENIA LÓPEZ CRUZ	LOCY871111RE3	SECRETARIA ACADEMICA DE INSTITUTO "B"	CESMECA
6	MTRA. ADRIANA GUADALUPE RAMOS ZEPEDA	RAZA900305FL2	JEFE DE OFICINA "B"	CESMECA
7	DR. EMMANUEL NÁJERA DE LEÓN	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA
8	LIC. GABRIELA FRAGOSO SAMANIEGO	FASG651225TJ2	JEFE DE OFICINA "A"	CESMECA
9	LIC. ROBERTO RICO CHONG	RICR600524I34	SECRETARIO DE EXTENSIÓN Y VINCULACIÓN "A"	CESMECA
10	C.P. PATRICIA BALLINAS SALAZAR	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA
11	C.P. PATRICIA RUIZ PÉREZ	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA
13	LIC. JUAN JESÚS PÉREZ GÓMEZ	PEGJ820128NXA	TECNICO ACADEMICO ASOCIADO "C"	CESMECA
14	LIC. OLGA PATRICIA DE LA CRUZ GONZALEZ	CUAO961108HE3	JEFE DE OFICINA "A"	CESMECA
15	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA
16	C. MARIELY JANETH NAVA GENOVÉS	NAGM9907304VA	INTENDENTE "C"	CESMECA
17	C. YANETH MERA CALVA	MECA870122-JD3	ADMINISTRATIVO "B"	CESMECA
18	ROBERTO ANTONIO MÉNDEZ GARCÍA	MEGR8406119S0	TECNICO EN MANTENIMIENTO "A"	CESMECA
19	C. BRENDA KARINA MEDINA VILLAFUERTE	MEVB8404031K1	AUXILIAR ADMINISTRATIVO "A"	CESMECA
20	C. MELESIO VALENTÍN MÉNDEZ GARCÍA	MEGM860212PB5	INTENDENTE "A"	CESMECA
21	C. DORA JUVENALIA GORDILLO ESTRADA	GOED721218S25	TECNICO ESPECIALIZADO "C"	CESMECA
22	C. IRMA CECILIA MEDINA VILLAFUERTE	MEVI7307023E6	ADMINISTRATIVO CALIFICADO "A"	CESMECA
24	ROBERTO CARLOS HOOVER SILVANO	HOSR760103LR7	TECNICO ACADEMICO	CESMECA
25	C. SAMUEL DE JESÚS GÓMEZ GONZÁLEZ	GGSJ801220TNA	JEFE DE SECCIÓN "A"	CESMECA
12	LIC. EGNER VAZQUEZ LÓPEZ	VALE870125AI7	TECNICO ACADEMICO ASOCIADO "C"	CESMECA
30	GUADALUPE GONZÁLEZ PALE	GOPG660415R85	JEFE DE SECCIÓN "B"	CESMECA
31	ANA MARÍA DE LA CRUZ GONZÁLEZ	CUGA900417HJ3	JEFE DE OFICINA "A"	CESMECA
32	SAMUEL DE JESÚS GÓMEZ GONZÁLEZ	GOGS801220TNA	JEFE SECCIÓN "A"	CESMECA
35	MARÍA DEL CARMEN GARCÍA AGUILAR	GAAC560716BA6	INVESTIGADOR DE TC. TITULAR "C"	CESMECA
37	MARÍA DE LOURDES MORALES VARGAS	MOVL811117IL5	PROFESOR INVESTIGADOR DE TC. ASOCIADO "B"	CESMECA
38	ROBERTO CARLOS HOOVER SILVANO	HOSR760103LR7	TÉCNICO ACADÉMICO TITULAR "A"	CESMECA
40	MAGDA ESTRELLA ZÚÑIGA ZENTENO	ZUZM660702P91	INVESTIGADOR DE TC: TITULAR "C"	CESMECA
39	DR. RAÚL ARRIAGA ORTIZ	AIOR760719NL4	PROFESOR INVESTIGADOR DE TC. TITULAR "A"	CESMECA
33	DRA. FLOR MARINA BERMÚDEZ URBINA	BEUF790118S43	INVESTIGADOR DE TC: TITULAR "C"	CESMECA
41	ING. LUIS GERARDO MORALES RAMOS	MORL730406FM3	JEFE DE SECCION "C"	CESMECA
36	LIC. IDOLINA GUZMÁN CORONADO	GUCI771224HPO	TÉCNICO ACADÉMICO TITULAR "C"	CESMECA
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.usuarios (id, username, password, nombre, rol, activo) FROM stdin;
1	jmolina	cesmeca2026	Jenny Molina	Administradora	t
2	pballinas	cesmeca2026	Patricia Ballinas	Auxiliar	t
3	pruiz	cesmeca2026	Patricia Ruiz	Auxiliar	t
4	dgordillo	cesmeca2026	Dora Gordillo	Auxiliar	t
5	odelacruz	cesmeca2026	Olga Patricia De La Cruz González	Auxiliar	t
6	admin	admin123	Roberto (Super Admin)	Administrador	t
\.


--
-- Data for Name: vehiculos; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.vehiculos (id, marca, modelo, placas) FROM stdin;
1	Chevrolet	Colorado	CY-2995-H
2	Honda	CRV	DNG-272-J
3	Toyota	Yaris	DNG-273-J
\.


--
-- Name: autoridades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.autoridades_id_seq', 6, true);


--
-- Name: bitacora_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.bitacora_id_seq', 29, true);


--
-- Name: claves_presupuestales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.claves_presupuestales_id_seq', 6, true);


--
-- Name: claves_programaticas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.claves_programaticas_id_seq', 6, true);


--
-- Name: ordenes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ordenes_id_seq', 20, true);


--
-- Name: personal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.personal_id_seq', 41, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 6, true);


--
-- Name: vehiculos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.vehiculos_id_seq', 3, true);


--
-- Name: autoridades autoridades_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.autoridades
    ADD CONSTRAINT autoridades_pkey PRIMARY KEY (id);


--
-- Name: autoridades autoridades_rol_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.autoridades
    ADD CONSTRAINT autoridades_rol_key UNIQUE (rol);


--
-- Name: bitacora bitacora_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.bitacora
    ADD CONSTRAINT bitacora_pkey PRIMARY KEY (id);


--
-- Name: claves_presupuestales claves_presupuestales_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.claves_presupuestales
    ADD CONSTRAINT claves_presupuestales_pkey PRIMARY KEY (id);


--
-- Name: claves_programaticas claves_programaticas_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.claves_programaticas
    ADD CONSTRAINT claves_programaticas_pkey PRIMARY KEY (id);


--
-- Name: ordenes ordenes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ordenes
    ADD CONSTRAINT ordenes_pkey PRIMARY KEY (id);


--
-- Name: personal personal_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.personal
    ADD CONSTRAINT personal_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_username_key UNIQUE (username);


--
-- Name: vehiculos vehiculos_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehiculos
    ADD CONSTRAINT vehiculos_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict e1w05nY39ZXUbVnakIjJYtPoCwz3gnyQW3AyErGivYbfvXnaJjFQUUYTT1mJs76

