--
-- PostgreSQL database dump
--

\restrict ffrBEb0sQ8W5ItXPcNtMSqBD218cgg6ys321rBvX9BTi5w88Jf9mFretCC12HmM

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: autoridades; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.autoridades (
    id integer NOT NULL,
    rol character varying(50),
    nombre character varying(200),
    cargo character varying(150),
    activo boolean DEFAULT true
);


ALTER TABLE public.autoridades OWNER TO admin;

--
-- Name: autoridades_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.autoridades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.autoridades_id_seq OWNER TO admin;

--
-- Name: autoridades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.autoridades_id_seq OWNED BY public.autoridades.id;


--
-- Name: bitacora; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.bitacora (
    id integer NOT NULL,
    usuario character varying(100) NOT NULL,
    accion character varying(50) NOT NULL,
    folio character varying(50),
    detalles text,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bitacora OWNER TO admin;

--
-- Name: bitacora_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.bitacora_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bitacora_id_seq OWNER TO admin;

--
-- Name: bitacora_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.bitacora_id_seq OWNED BY public.bitacora.id;


--
-- Name: claves_presupuestales; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.claves_presupuestales (
    id integer NOT NULL,
    clave character varying(100) NOT NULL,
    descripcion text
);


ALTER TABLE public.claves_presupuestales OWNER TO admin;

--
-- Name: claves_presupuestales_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.claves_presupuestales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.claves_presupuestales_id_seq OWNER TO admin;

--
-- Name: claves_presupuestales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.claves_presupuestales_id_seq OWNED BY public.claves_presupuestales.id;


--
-- Name: claves_programaticas; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.claves_programaticas (
    id integer NOT NULL,
    clave character varying(100) NOT NULL,
    descripcion text
);


ALTER TABLE public.claves_programaticas OWNER TO admin;

--
-- Name: claves_programaticas_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.claves_programaticas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.claves_programaticas_id_seq OWNER TO admin;

--
-- Name: claves_programaticas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.claves_programaticas_id_seq OWNED BY public.claves_programaticas.id;


--
-- Name: ordenes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ordenes (
    id integer NOT NULL,
    comisionado character varying(255) NOT NULL,
    lugar character varying(255) NOT NULL,
    fecha_inicio date,
    fecha_fin date,
    estatus character varying(50) DEFAULT 'Borrador'::character varying,
    rfc character varying(20),
    categoria character varying(100),
    adscripcion character varying(100),
    motivo text,
    hora_salida time without time zone,
    hora_regreso time without time zone,
    medio_transporte character varying(50),
    vehiculo_marca character varying(50),
    vehiculo_modelo character varying(50),
    vehiculo_placas character varying(20),
    clave_programatica text,
    cuota_diaria text DEFAULT 0,
    importe_combustible numeric(10,2) DEFAULT 0,
    importe_pasajes numeric(10,2) DEFAULT 0,
    importe_viaticos numeric(10,2) DEFAULT 0,
    importe_otros numeric(10,2) DEFAULT 0,
    importe_total numeric(10,2) DEFAULT 0,
    importe_pasajes_aereos numeric(10,2) DEFAULT 0,
    importe_congresos numeric(10,2) DEFAULT 0,
    tipo_comision character varying(50) DEFAULT 'Nacional'::character varying,
    fecha_elaboracion date DEFAULT CURRENT_DATE,
    numero_folio integer,
    anio_folio integer,
    informe_actividades text,
    es_fechas_multiples boolean DEFAULT false,
    periodo_texto text,
    dias_salida text,
    dias_regreso text,
    usuario_modificador character varying(255)
);


ALTER TABLE public.ordenes OWNER TO admin;

--
-- Name: ordenes_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.ordenes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordenes_id_seq OWNER TO admin;

--
-- Name: ordenes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.ordenes_id_seq OWNED BY public.ordenes.id;


--
-- Name: personal; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.personal (
    id integer NOT NULL,
    nombre character varying(200),
    rfc character varying(50),
    categoria character varying(150),
    adscripcion character varying(150)
);


ALTER TABLE public.personal OWNER TO admin;

--
-- Name: personal_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.personal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_id_seq OWNER TO admin;

--
-- Name: personal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.personal_id_seq OWNED BY public.personal.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    nombre character varying(100) NOT NULL,
    rol character varying(50) NOT NULL,
    activo boolean DEFAULT true
);


ALTER TABLE public.usuarios OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO admin;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: vehiculos; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.vehiculos (
    id integer NOT NULL,
    marca character varying(100),
    modelo character varying(100),
    placas character varying(50)
);


ALTER TABLE public.vehiculos OWNER TO admin;

--
-- Name: vehiculos_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.vehiculos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehiculos_id_seq OWNER TO admin;

--
-- Name: vehiculos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.vehiculos_id_seq OWNED BY public.vehiculos.id;


--
-- Name: autoridades id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.autoridades ALTER COLUMN id SET DEFAULT nextval('public.autoridades_id_seq'::regclass);


--
-- Name: bitacora id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.bitacora ALTER COLUMN id SET DEFAULT nextval('public.bitacora_id_seq'::regclass);


--
-- Name: claves_presupuestales id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.claves_presupuestales ALTER COLUMN id SET DEFAULT nextval('public.claves_presupuestales_id_seq'::regclass);


--
-- Name: claves_programaticas id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.claves_programaticas ALTER COLUMN id SET DEFAULT nextval('public.claves_programaticas_id_seq'::regclass);


--
-- Name: ordenes id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ordenes ALTER COLUMN id SET DEFAULT nextval('public.ordenes_id_seq'::regclass);


--
-- Name: personal id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.personal ALTER COLUMN id SET DEFAULT nextval('public.personal_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Name: vehiculos id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehiculos ALTER COLUMN id SET DEFAULT nextval('public.vehiculos_id_seq'::regclass);


--
-- Data for Name: autoridades; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.autoridades (id, rol, nombre, cargo, activo) FROM stdin;
1	DIRECTOR	DR. EMMANUEL NÁJERA DE LEÓN	DIRECTOR CESMECA-UNICACH	t
2	SECRETARIO	LIC. ENRIQUE PÉREZ LÓPEZ	SECRETARIO ACADÉMICO-UNICACH	t
3	RECTORA	ARQUEOL. JUANA DE DIOS LÓPEZ JIMÉNEZ	RECTORA	t
\.


--
-- Data for Name: bitacora; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.bitacora (id, usuario, accion, folio, detalles, fecha) FROM stdin;
1	admin	LOGIN	\N	Inicio de sesión	2026-03-25 16:46:45.595013
2	pballinas	LOGIN	\N	Inicio de sesión	2026-03-25 16:48:29.964406
3	admin	LOGIN	\N	Inicio de sesión	2026-03-25 17:04:25.801086
4	Sistema	CREAR	081/CESMECA/2026	Creada para C.P. PATRICIA BALLINAS SALAZAR	2026-03-25 17:05:33.337836
5	admin	LOGIN	\N	Inicio de sesión	2026-03-25 18:06:34.934278
6	pballinas	LOGIN	\N	Inicio de sesión	2026-03-25 19:45:18.032463
7	admin	LOGIN	\N	Inicio de sesión	2026-03-25 19:45:56.046279
8	pruiz	LOGIN	\N	Inicio de sesión	2026-03-25 22:37:00.994571
9	Patricia Ruiz	EDITAR	081/CESMECA/2026	Modificada por Patricia Ruiz	2026-03-25 22:37:23.513862
10	admin	LOGIN	\N	Inicio de sesión	2026-03-25 22:37:41.158608
11	admin	LOGIN	\N	Inicio de sesión	2026-03-27 07:56:23.486563
12	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 07:57:08.799217
13	admin	LOGIN	\N	Inicio de sesión	2026-03-27 08:36:06.579762
14	admin	LOGIN	\N	Inicio de sesión	2026-03-27 14:59:51.2423
15	Patricia Ballinas	CREAR	082/CESMECA/2026	Creada para LIC. JENNY ARACELI MOLINA GOMEZ	2026-03-27 15:56:11.616482
16	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 16:03:08.729305
17	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:04:44.57743
18	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:05:46.953746
19	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:06:30.661105
20	admin	LOGIN	\N	Inicio de sesión	2026-03-27 16:07:38.360703
21	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:16:58.776338
22	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 16:31:53.865048
23	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 16:37:05.572217
24	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:43:49.730678
25	Patricia Ballinas	EDITAR	082/CESMECA/2026	Modificada por Patricia Ballinas	2026-03-27 16:44:21.243257
26	admin	LOGIN	\N	Inicio de sesión	2026-03-27 18:55:54.116286
27	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 18:57:36.764051
28	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 19:16:41.632068
29	pballinas	LOGIN	\N	Inicio de sesión	2026-03-27 20:25:55.625808
30	dgordillo	LOGIN	\N	Inicio de sesión	2026-04-13 19:18:49.963152
31	Patricia Ruiz	CREAR	083/CESMECA/2026	Creada para LIC. GABRIELA FRAGOSO SAMANIEGO	2026-04-13 20:12:15.99322
32	Patricia Ruiz	EDITAR	083/CESMECA/2026	Modificada por Patricia Ruiz	2026-04-13 20:13:30.498155
33	Patricia Ruiz	EDITAR	083/CESMECA/2026	Modificada por Patricia Ruiz	2026-04-13 20:15:07.191552
34	dgordillo	ELIMINAR	083/CESMECA/2026	Se eliminó la orden de LIC. GABRIELA FRAGOSO SAMANIEGO	2026-04-13 20:16:44.22007
35	Dora Gordillo	CREAR	083/CESMECA/2026	Creada para Marisol Anzo Escobar 	2026-04-13 20:36:17.313903
36	Dora Gordillo	EDITAR	083/CESMECA/2026	Modificada por Dora Gordillo	2026-04-13 20:42:53.41907
37	Dora Gordillo	EDITAR	083/CESMECA/2026	Modificada por Dora Gordillo	2026-04-13 20:46:08.058653
38	Patricia Ballinas	EDITAR	006/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 16:27:33.196904
39	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 17:01:58.814332
40	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 17:02:17.813694
41	Patricia Ballinas	CREAR	084/CESMECA/2026	Creada para DR. EMMANUEL NÁJERA DE LEÓN	2026-04-14 17:23:52.705738
42	Patricia Ballinas	EDITAR	084/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 17:25:55.945293
43	pballinas	LOGIN	\N	Inicio de sesión	2026-04-14 17:41:24.194331
44	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 17:44:24.670849
45	Patricia Ballinas	CREAR	085/CESMECA/2026	Creada para DR. EMMANUEL NÁJERA DE LEÓN	2026-04-14 17:45:52.713634
46	Patricia Ballinas	EDITAR	085/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 17:55:19.952162
47	Patricia Ballinas	EDITAR	085/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 17:57:24.71587
48	Patricia Ballinas	CREAR	086/CESMECA/2026	Creada para DR. EMMANUEL NÁJERA DE LEÓN	2026-04-14 17:58:48.73455
49	Patricia Ballinas	CREAR	087/CESMECA/2026	Creada para DR. EMMANUEL NÁJERA DE LEÓN	2026-04-14 18:01:32.379439
50	Patricia Ballinas	CREAR	088/CESMECA/2026	Creada para DR. EMMANUEL NÁJERA DE LEÓN	2026-04-14 18:03:06.69649
51	Patricia Ballinas	EDITAR	087/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 18:05:51.874666
52	pballinas	ELIMINAR	088/CESMECA/2026	Se eliminó la orden de DR. EMMANUEL NÁJERA DE LEÓN	2026-04-14 19:34:07.109527
53	pballinas	ELIMINAR	087/CESMECA/2026	Se eliminó la orden de DR. EMMANUEL NÁJERA DE LEÓN	2026-04-14 19:34:10.227222
54	pballinas	ELIMINAR	086/CESMECA/2026	Se eliminó la orden de DR. EMMANUEL NÁJERA DE LEÓN	2026-04-14 19:34:20.588655
55	Patricia Ballinas	EDITAR	084/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 19:39:02.367923
56	Patricia Ballinas	EDITAR	085/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 19:42:09.25983
57	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 19:42:16.928344
58	Patricia Ballinas	EDITAR	084/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 19:51:56.497921
59	Patricia Ballinas	EDITAR	084/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 19:57:49.357178
60	Patricia Ballinas	EDITAR	085/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 19:59:16.282467
61	Patricia Ballinas	EDITAR	085/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:00:08.28718
62	Patricia Ballinas	EDITAR	085/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:22:38.574502
63	Patricia Ballinas	EDITAR	084/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:24:53.738491
64	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:30:29.69427
65	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:38:00.24256
66	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:38:24.944621
67	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:38:39.514591
68	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:39:23.229069
69	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:39:49.657018
70	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:40:20.670498
71	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:42:02.145036
72	Patricia Ruiz	CREAR	084/CESMECA/2026	Creada para C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	2026-04-14 20:42:19.995596
73	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:46:43.497387
74	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:47:10.215031
75	Patricia Ruiz	CREAR	085/CESMECA/2026	Creada para C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	2026-04-14 20:47:40.749593
76	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:52:21.24004
77	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:52:29.54809
78	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:53:47.622447
79	Patricia Ballinas	EDITAR	046/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:56:35.461139
80	Patricia Ballinas	EDITAR	046/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 20:59:06.389853
81	Patricia Ruiz	CREAR	086/CESMECA/2026	Creada para C.P. PATRICIA RUIZ PÉREZ	2026-04-14 21:16:21.442311
82	Patricia Ruiz	EDITAR	086/CESMECA/2026	Modificada por Patricia Ruiz	2026-04-14 21:17:46.008448
83	Patricia Ruiz	EDITAR	086/CESMECA/2026	Modificada por Patricia Ruiz	2026-04-14 21:26:13.584911
84	Patricia Ballinas	CREAR	087/CESMECA/2026	Creada para C.P. YENNY REYES ROQUE	2026-04-14 21:38:44.524575
85	Patricia Ballinas	EDITAR	087/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 21:39:02.451251
86	Patricia Ballinas	CREAR	088/CESMECA/2026	Creada para C.P. YENNY REYES ROQUE	2026-04-14 21:41:40.466031
87	Patricia Ballinas	EDITAR	088/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 21:43:31.533365
88	Patricia Ballinas	EDITAR	088/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 21:44:37.030563
89	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 21:45:15.784055
90	Patricia Ballinas	EDITAR	046/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-14 21:45:55.40688
91	Patricia Ballinas	CREAR	089/CESMECA/2026	Creada para C.P. YENNY REYES ROQUE	2026-04-14 21:47:58.835005
92	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 14:21:41.760276
93	Patricia Ballinas	EDITAR	046/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 14:30:51.668595
94	pballinas	LOGIN	\N	Inicio de sesión	2026-04-15 14:32:57.091614
95	pballinas	LOGIN	\N	Inicio de sesión	2026-04-15 14:40:18.582227
96	Patricia Ballinas	EDITAR	015/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 15:21:30.68638
97	Patricia Ballinas	EDITAR	040/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 15:22:30.264059
98	Dora Gordillo	EDITAR	083/CESMECA/2026	Modificada por Dora Gordillo	2026-04-15 15:26:47.259951
99	Patricia Ballinas	EDITAR	061/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 15:53:17.39557
100	Patricia Ballinas	EDITAR	061/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 15:57:27.074804
101	Patricia Ballinas	EDITAR	061/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 15:59:02.756653
102	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 16:31:08.847528
103	Patricia Ballinas	EDITAR	076/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 17:58:14.713269
104	Patricia Ballinas	EDITAR	076/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 17:58:42.716276
105	Patricia Ballinas	EDITAR	076/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 18:03:57.510699
106	Patricia Ballinas	EDITAR	007/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 18:52:56.707793
107	Patricia Ballinas	EDITAR	020/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 18:54:06.79709
108	Patricia Ballinas	EDITAR	046/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 18:54:50.606837
109	Patricia Ballinas	EDITAR	015/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 18:56:32.642115
110	Patricia Ballinas	EDITAR	040/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 18:57:29.460227
111	Patricia Ballinas	EDITAR	061/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-15 18:58:26.980297
112	Dora Gordillo	CREAR	087/CESMECA/2026	Creada para DELMY TANIA CRUZ HERNÁNDEZ	2026-04-15 21:19:35.47881
113	Dora Gordillo	EDITAR	087/CESMECA/2026	Modificada por Dora Gordillo	2026-04-15 21:22:19.314289
114	pballinas	LOGIN	\N	Inicio de sesión	2026-04-15 21:30:05.011517
115	Patricia Ballinas	CREAR	088/CESMECA/2026	Creada para C.P. PATRICIA BALLINAS SALAZAR	2026-04-16 15:26:20.939877
116	Patricia Ballinas	EDITAR	078/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-16 15:28:14.565925
117	Patricia Ballinas	CREAR	089/CESMECA/2026	Creada para C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	2026-04-16 15:33:24.524059
118	Patricia Ballinas	CREAR	090/CESMECA/2026	Creada para C.P. PATRICIA BALLINAS SALAZAR	2026-04-16 15:35:09.087012
119	Patricia Ballinas	CREAR	091/CESMECA/2026	Creada para C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	2026-04-16 15:36:04.825321
120	Patricia Ballinas	CREAR	092/CESMECA/2026	Creada para C.P. PATRICIA RUIZ PÉREZ	2026-04-16 15:39:14.203067
121	Patricia Ballinas	EDITAR	092/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-16 15:39:32.776116
122	Dora Gordillo	EDITAR	076/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 17:21:52.392525
123	Dora Gordillo	EDITAR	076/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 17:23:11.744281
124	Dora Gordillo	EDITAR	076/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 17:23:51.140656
125	Dora Gordillo	CREAR	093/CESMECA/2026	Creada para C.P. YENNY REYES ROQUE	2026-04-16 17:27:50.249342
126	Dora Gordillo	EDITAR	076/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 17:30:02.690713
127	Dora Gordillo	EDITAR	093/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 17:30:54.99827
128	Dora Gordillo	CREAR	094/CESMECA/2026	Creada para MTRA. YESENIA LÓPEZ CRUZ	2026-04-16 17:37:00.752407
129	Dora Gordillo	EDITAR	087/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 17:39:44.468651
130	Dora Gordillo	EDITAR	093/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 17:59:28.667984
131	Dora Gordillo	EDITAR	094/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 18:00:13.825199
132	Dora Gordillo	EDITAR	094/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 18:08:37.162248
133	Dora Gordillo	EDITAR	093/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 18:10:54.696321
134	Dora Gordillo	EDITAR	083/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 20:04:34.20404
135	Dora Gordillo	EDITAR	083/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 20:04:56.628664
136	Dora Gordillo	EDITAR	087/CESMECA/2026	Modificada por Dora Gordillo	2026-04-16 20:06:46.153866
137	Patricia Ballinas	CREAR	095/CESMECA/2026	Creada para MTRA. NORMA GUADALUPE PÉREZ LÓPEZ	2026-04-17 17:30:15.036084
138	Patricia Ballinas	CREAR	096/CESMECA/2026	Creada para MTRA. NORMA GUADALUPE PÉREZ LÓPEZ	2026-04-17 17:33:46.039606
139	Patricia Ballinas	EDITAR	095/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-17 17:34:11.758764
140	Patricia Ballinas	EDITAR	095/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-17 17:41:58.983388
141	Patricia Ballinas	EDITAR	095/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-17 17:42:48.87081
142	Patricia Ballinas	CREAR	097/CESMECA/2026	Creada para MTRA. NORMA GUADALUPE PÉREZ LÓPEZ	2026-04-17 17:44:50.102893
143	Patricia Ballinas	EDITAR	076/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-20 17:15:00.774134
144	pruiz	LOGIN	\N	Inicio de sesión	2026-04-20 18:19:38.395241
145	dgordillo	LOGIN	\N	Inicio de sesión	2026-04-20 18:20:01.858882
146	admin	LOGIN	\N	Inicio de sesión	2026-04-20 18:20:31.757659
147	dgordillo	LOGIN	\N	Inicio de sesión	2026-04-20 18:32:15.641312
148	Patricia Ballinas	EDITAR	095/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-20 18:59:40.847838
149	Patricia Ballinas	EDITAR	096/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-20 18:59:58.468435
150	Patricia Ballinas	EDITAR	097/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-20 19:00:23.492029
151	Patricia Ballinas	EDITAR	097/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-20 19:02:18.37146
152	Patricia Ruiz	CREAR	098/CESMECA/2026	Creada para LIC. IDOLINA GUZMÁN CORONADO	2026-04-20 19:08:38.413628
153	Patricia Ruiz	EDITAR	098/CESMECA/2026	Modificada por Patricia Ruiz	2026-04-20 19:08:47.873938
154	Patricia Ruiz	EDITAR	098/CESMECA/2026	Modificada por Patricia Ruiz	2026-04-20 19:09:29.232508
155	Patricia Ruiz	EDITAR	098/CESMECA/2026	Modificada por Patricia Ruiz	2026-04-20 19:09:39.553708
156	pballinas	LOGIN	\N	Inicio de sesión	2026-04-20 19:44:12.550467
157	pballinas	LOGIN	\N	Inicio de sesión	2026-04-20 19:50:42.64706
158	pruiz	LOGIN	\N	Inicio de sesión	2026-04-20 19:57:15.959071
159	Patricia Ballinas	EDITAR	037/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-20 20:01:31.389172
160	Patricia Ballinas	EDITAR	037/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-20 20:01:44.160955
161	Patricia Ballinas	EDITAR	042/CESMECA/2026	Modificada por Patricia Ballinas	2026-04-20 20:02:47.88388
162	pballinas	LOGIN	\N	Inicio de sesión	2026-04-20 20:27:21.729466
163	Dora Gordillo	CREAR	099/CESMECA/2026	Creada para DR. EMMANUEL NÁJERA DE LEÓN	2026-04-21 17:01:59.724623
164	Dora Gordillo	EDITAR	099/CESMECA/2026	Modificada por Dora Gordillo	2026-04-21 17:08:52.704517
165	Dora Gordillo	EDITAR	099/CESMECA/2026	Modificada por Dora Gordillo	2026-04-21 17:15:32.183802
166	Dora Gordillo	EDITAR	099/CESMECA/2026	Modificada por Dora Gordillo	2026-04-21 17:15:32.300843
167	Dora Gordillo	EDITAR	099/CESMECA/2026	Modificada por Dora Gordillo	2026-04-21 20:09:06.77746
168	Dora Gordillo	CREAR	100/CESMECA/2026	Creada para MTRA. YESENIA LÓPEZ CRUZ	2026-04-21 20:21:50.992408
\.


--
-- Data for Name: claves_presupuestales; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.claves_presupuestales (id, clave, descripcion) FROM stdin;
1	26111	COMBUSTIBLE
2	37111	PASAJES NACIONALES AÉREOS
3	37211	PASAJES NACIONALES TERRESTRES
4	37511	VIÁTICOS NACIONALES
5	38301	CONGRESOS Y CONVENCIONES
6	39202	OTROS IMPUESTOS Y DERECHOS
\.


--
-- Data for Name: claves_programaticas; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.claves_programaticas (id, clave, descripcion) FROM stdin;
1	4008000 (0121) 2.06.PRDI101.PYI001	Dependencia 4008000 - Fondo 0121
2	4008000 (0121) 2.06.PRDI1029.PYI029	Dependencia 4008000 - Fondo 0121
3	4008000 (0121) 2.06.PRDI1034.PYI034	Dependencia 4008000 - Fondo 0121
4	4008000 (0121) 2.06.PRDI202.PYI002	Dependencia 4008000 - Fondo 0121
5	4008000 (0121) 2.06.PRDI506.PYI006	Dependencia 4008000 - Fondo 0121
6	4008000 (0121) 2.06.PRDI614.PYI014	Dependencia 4008000 - Fondo 0121
7	4008010 0121 1.04.PRDI106.PYI006 	Dependencia 4008010 - Fondo: 0121 
8	4008010 0121 1.06.PRDI1030.PYI030	Dependencia 4008010 - Fondo: 0121 \n
9	4008010 0121 1.06.PRDI506.PYI006 	Dependencia 4008010 - Fondo 0121 \n
10	4052050 0121 1.07.PRDI1030.PYI030 	Dependencia 4052050 -Fondo: 0121 
11	4052050 0121 1.07.PRDI506.PYI006 	Dependencia 4052050 -Fondo: 0121 \n 
12	4008020 0121 1.04.PRDI106.PYI006 	Dependencia 4008020 -Fondo: 0121 \n
13	4008020 0121 1.06.PRDI101.PYI001	Dependencia 4008020 -Fondo: 0121 \n
14	4008020 0121 1.06.PRDI303.PYI003	Dependencia 4008020 -Fondo: 0121 \n
15	4008020 0121 1.06.PRDI505.PYI005	Dependencia 4008020 -Fondo: 0121 \n
16	4008020 0121 1.06.PRDI508.PYI008	Dependencia 4008020 -Fondo: 0121 \n
17	4051990 0121 1.07.PRDI506.PYI006 	Dependencia 4051990 -Fondo: 0121 \n 
\.


--
-- Data for Name: ordenes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ordenes (id, comisionado, lugar, fecha_inicio, fecha_fin, estatus, rfc, categoria, adscripcion, motivo, hora_salida, hora_regreso, medio_transporte, vehiculo_marca, vehiculo_modelo, vehiculo_placas, clave_programatica, cuota_diaria, importe_combustible, importe_pasajes, importe_viaticos, importe_otros, importe_total, importe_pasajes_aereos, importe_congresos, tipo_comision, fecha_elaboracion, numero_folio, anio_folio, informe_actividades, es_fechas_multiples, periodo_texto, dias_salida, dias_regreso, usuario_modificador) FROM stdin;
6	DR. EMMANUEL NÁJERA DE LEÓN	Tuxtla Gutiérrez, Chiapas	2026-01-16	2026-01-16	Borrador	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas, para asistir a una reunión de trabajo para dar seguimiento y tratar asuntos inherentes a los Posgrados, en la sala Mauro Moreno Corzo en CU de la UNICACH.	08:00:00	16:00:00	Terrestre	\N	\N	\N	4008000 (0121) 2.06.PRDI1029.PYI029	1 x $900.00 = $900.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-01-15	6	2026	\N	f	\N	\N	\N	\N
2	C.P. PATRICIA BALLINAS SALAZAR	Ciudad de México	2026-02-23	2026-02-27	Borrador	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA	Viajar a la Ciudad de Tuxtla Gutiérrez para realizar seguimiento Institucional del CESMECA, en Rectoría, Secretarías y\nDepartamentos de la UNICACH. El importe será con cargo al POA 2025, del proyecto denominado: Programa para fortalecer la gestión administrativa de las unidades académicas y administrativas, Programa Institucional Consolidación del Posgrado y Programa Institucional de Divulgación, Vinculación y Servicios Universitarios.	08:00:00	16:00:00	Aéreo	\N	\N	\N	4008000 (0121) 2.06.PRDI101.PYI001	\N	0.00	1000.00	6000.00	0.00	16000.00	6000.00	3000.00	Internacional	2026-02-20	2	2026	\N	f	\N	\N	\N	\N
4	DR. EMMANUEL NÁJERA DE LEÓN	Francia	2026-02-23	2026-02-27	Borrador	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA	Viajar a la Ciudad de Tuxtla Gutiérrez para realizar seguimiento Institucional del CESMECA, en Rectoría, Secretarías y Departamentos de la UNICACH. El importe será con cargo al POA 2025, del proyecto denominado: Programa para fortalecer la gestión administrativa de las unidades académicas y administrativas, Programa Institucional Consolidación del Posgrado y Programa Institucional de Divulgación, Vinculación y Servicios Universitarios.	08:00:00	23:00:00	Aéreo	\N	\N	\N	4008000 (0121) 2.06.PRDI202.PYI002	\N	0.00	0.00	20000.00	5000.00	55000.00	20000.00	10000.00	Internacional	2026-02-20	4	2026	\N	f	\N	\N	\N	\N
20	LIC. JENNY ARACELI MOLINA GOMEZ	Tuxtla Gutiérrez	2026-03-27	2026-03-27	Borrador	MOGJ801228AU0	SECRETARIO ADMINISTRATIVO DE INSTITUTO "A"	CESMECA	Para realizar tramites administrativos y entrega de valija en Rectoría, Ciudad Universitaria y en CAMPUS, de la UNICACH. con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	\N	½ x $1,510.16 = $1,510.16	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-02-25	82	2026	\N	f				\N
1	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas.	2026-02-20	2026-02-20	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	Viajar a la Ciudad de Tuxtla Gutiérrez para realizar seguimiento Institucional del CESMECA, en Rectoría, Secretarías y Departamentos de la UNICACH. El importe será con cargo al POA 2025, del proyecto denominado: Programa para fortalecer la gestión administrativa de las unidades académicas y administrativas, Programa Institucional Consolidación del posgrado y Programa Institucional de Divulgación, Vinculación y Servicios Universitarios.	08:00:00	16:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008000 (0121) 2.06.PRDI101.PYI001	\N	1000.00	0.00	450.00	200.00	1650.00	0.00	0.00	Nacional	2026-02-20	1	2026	\N	f	\N	\N	\N	\N
5	C.P. PATRICIA RUIZ PÉREZ	Tuxtla Gutiérrez, Chiapas	2026-02-25	2026-02-25	Borrador	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA	xxxxxxxxxxxxxxxxxxxxxxxxxx	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI101.PYI001, 4008000 (0121) 2.06.PRDI614.PYI014	1 x $450.00\n½ x $225.00 = $675.00	1000.00	0.00	450.00	200.00	1650.00	0.00	0.00	Nacional	2026-02-24	5	2026	\N	f	\N	\N	\N	\N
7	DR. EMMANUEL NÁJERA DE LEÓN	Tuxtla Gutiérrez, Chiapas	2026-01-16	2026-01-16	Borrador	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas, para asistir a una reunión de trabajo para dar seguimiento y tratar asuntos inherentes a los Posgrados, en la sala Mauro Moreno Corzo en CU de la UNICACH.	08:30:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $1,510.16 = $1,510.16	600.00	0.00	0.00	0.00	600.00	0.00	0.00	Nacional	2026-01-15	7	2026	\N	f				\N
22	 Dra. Marisol Anzo Escobar 	LEÓN GUANAJUATO 	2026-05-20	2026-05-22	Borrador	AOEM850528DK0	PROFESOR INVESTIGADOR DE TC.ASOCIADO "C"	CESMECA	Viajar a la Ciudad de León, Guanajuato, para participar como conferenciasta en el XXIII  encuentro: "Participacion de la Mujer\n en la Ciencia" que se realizara del 20 al 22 de mayo del presente año  en el Centro de Investigaciones  en Optica ubicado  en la Ciudad de León Guanajuato.	\N	\N	Aéreo	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-04-13	83	2026	\N	f				\N
3	C. DORA JUVENALIA GORDILLO ESTRADA	Tuxtla Gutiérrez, Chiapas.	2026-02-27	2026-02-27	Borrador	GOED721218S25	TECNICO ESPECIALIZADO "C"	CESMECA	Viajar a la Ciudad de Tuxtla Gutiérrez, para asistir a una reunión al Consejo Universitario, en las instalaciones de Ciudad Universitaria. El importe será con cargo al POA 2018, del proyecto denominado: Programa para fortalecer la gestión administrativa de las unidades académicas.	08:00:00	16:00:00	Terrestre	\N	\N	\N	4008000 (0121) 2.06.PRDI614.PYI014	\N	0.00	140.00	450.00	0.00	590.00	0.00	0.00	Nacional	2026-02-20	3	2026	\N	f	\N	\N	\N	Dora Gordillo
42	MTRA. NORMA GUADALUPE PÉREZ LÓPEZ	Tuxtla Gutiérrez, Chiapas	2026-02-16	2026-02-16	Borrador	PELN800901569	COORDINADOR ACADÉMICO "B"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, para participar en una reunión de trabajo para la revisión de las plantillas académicas y planes de estudio de los Posgrados en Feminismos, en las oficias de Ciudad Universitaria de la UNICACH.	08:00:00	18:00:00	Terrestre	\N	\N	\N	4008020 0121 1.06.PRDI303.PYI003	½ x $1,510.16 = $1,510.16	0.00	140.00	0.00	0.00	140.00	0.00	0.00	Nacional	2026-02-13	37	2026	\N	f				Patricia Ballinas
12	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez Chiapas	\N	\N	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	viajar a tuxtla	\N	\N	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI101.PYI001	\N	0.00	0.00	0.00	0.00	50.00	0.00	50.00	Nacional	2026-03-18	68	2026	\N	t	11, 18, 19 de febrero 	11 de febrero de 2026\n18 de febrero de 2026\n19 de febrero de 2026	11 de febrero de 2026\n18 de febrero de 2026\n19 de febrero de 2026	\N
14	C.P. PATRICIA RUIZ PÉREZ	Tuxtla Gutiérrez Chiapas	2026-04-14	2026-04-14	Borrador	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria y Rectoría de la UNICACH, para realizar trámites administrativos y la entrega de valija	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	800.00	0.00	300.00	200.00	1300.00	0.00	0.00	Nacional	2026-03-24	77	2026	\N	f				\N
15	C.P. PATRICIA RUIZ PÉREZ	Tuxtla Gutiérrez Chiapas	2026-05-08	2026-05-08	Borrador	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria y Rectoría de la UNICACH, para realizar trámites administrativos y la entrega de valija. El importe será con cargo al POA  2026.\n	08:00:00	18:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008010 0121 1.04.PRDI106.PYI006 	½ x $970.82 = $970.82	800.00	0.00	300.00	210.00	1310.00	0.00	0.00	Nacional	2026-04-16	78	2026	\N	f				\N
11	DR. CARLOS DE JESÚS GÓMEZ ABARCA	CIUDAD DE MÉXICO	2026-03-04	2026-03-08	Borrador	GOAC840102PJ7	PROFESOR INVESTIGADOR DE TIEMPO COMPLETO TITULAR “A”	CESMECA	Viajar a la Ciudad de México, para asistir al Coloquio “América Central hoy. Autoritarismos, violencias y exilios” en la Sala 2 del Auditorio Pablo González Casanova, Instituto de Investigaciones Sociales, UNAM, Ciudad Universitaria. El importe será con cargo al POA 2026.	\N	\N	Aéreo	\N	\N	\N	4008000 (0121) 2.06.PRDI614.PYI014	4 x $5,393.44\n½ x $2,804.59 = $24,378.35	0.00	0.00	1791.11	0.00	5420.11	3629.00	0.00	Nacional	2026-03-02	67	2026	\N	f	\N	\N	\N	\N
16	C.P. PATRICIA BALLINAS SALAZAR	Tuxtla Gutiérrez Chiapas	2026-04-17	2026-04-17	Borrador	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria de la UNICACH y Rectoría de la UNICACH, para realizar tramites administrativos  y entrega de valija. El importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	800.00	0.00	300.00	200.00	1300.00	0.00	0.00	Nacional	2026-03-24	79	2026	\N	f				\N
18	LIC. EGNER VAZQUEZ LÓPEZ	Tuxtla Gutiérrez, Chiapas	2026-03-25	2026-03-25	Borrador	VALE870125AI7	TECNICO ACADEMICO ASOCIADO "C"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas, para la presentación de las Políticas y Calendario de Actividades para la\n Integración de Plantillas Pregrado y Posgrado, la cual se llevará a cabo el día 25 de marzo del año en curso a las 13:00 horas  en la Sala  de lectura informal (sala verde ) del Centro Universitario  de informacion  y documentacion  de C.U de la UNICACH.\n.	11:30:00	17:00:00	Terrestre	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-03-24	80	2026	\N	f				\N
19	C.P. PATRICIA BALLINAS SALAZAR	Tuxtla Gutiérrez Chiapas	2026-04-21	2026-04-21	Borrador	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria y Rectoría de la UNICACH, para realizar trámites administrativos y la entrega de valija. \nEl importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	800.00	0.00	300.00	200.00	1300.00	0.00	0.00	Nacional	2026-03-25	81	2026	\N	f				\N
8	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-02-27	2026-02-27	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1034.PYI034	1 x $900.00 = $900.00	1000.00	0.00	450.00	200.00	1650.00	0.00	0.00	Nacional	2026-02-25	8	2026	\N	f	\N	\N	\N	Dora Gordillo
24	DR. EMMANUEL NÁJERA DE LEÓN	Tuxtla Gutiérrez, Chiapas	2026-03-03	2026-03-03	Borrador	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas, para realizar el seguimiento Institucional del CESMECA, en Rectoría, secretarias y Departamentos de la UNICACH y para participar en una reunión de trabajo de alto nivel para establecer el grado de adopción del fundamento filosófico del Lekil Kuxlejal (Buen Vivir), los días 01, 02, 04, 05 y 07 de marzo de 2026.	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029, 4008010 0121 1.04.PRDI106.PYI006	½ x $1,510.16 = $1,510.16	1400.00	0.00	0.00	800.00	2200.00	0.00	0.00	Nacional	2026-02-27	46	2026	\N	t	01, 02, 04, 05 y 07 de marzo de 2026	01 de marzo 2026   8:30am\n02 de marzo 2026   8:30am\n04 de marzo 2026   8:30am\n05 de marzo 2026   8:30am\n07 de marzo 2026   8:30am	01 de marzo 2026   6:00pm\n02 de marzo 2026   6:00pm\n04 de marzo 2026   6:00pm\n05 de marzo 2026   6:00pm\n07 de marzo 2026   6:00pm	\N
13	MTRA. YESENIA LÓPEZ CRUZ	Tuxtla Gutiérrez, Chiapas	2026-03-17	2026-03-17	Borrador	LOCY871111RE3	SECRETARIA ACADEMICA DE INSTITUTO "B"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, con el propósito de asistir a reuniones y atender asuntos relacionados con los programas de Posgrados, en las oficinas de Rectoría de Bicentenario, Secretaría Académica e Investigación y Posgrado de Ciudad Universitaria de la UNICACH.	08:00:00	16:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008010 0121 1.06.PRDI506.PYI006 , 4008000 (0121) 2.06.PRDI1029.PYI029	½ x $1,510.16 = $1,510.16	471.67	0.00	0.00	300.00	771.67	0.00	0.00	Nacional	2026-03-16	76	2026	\N	t	17  y  27 de marzo de 2026.	17 de abril de 2026 8:30 am\n27 de abril de 2026 8:30 am	17 de abril de 2026 5:00 pm\n27 de abril de 2026 5:00 pm	\N
45	LIC. IDOLINA GUZMÁN CORONADO	Tuxtla Gutiérrez, Chiapas	2026-04-28	2026-04-28	Borrador	GUCI771224HPO	TÉCNICO ACADÉMICO TITULAR "C"	CESMECA	viajar a la ciudad de Tuxtla Gutiérrez, para hacer entrega de libros en la biblioteca de Ciudad Universitaria y reunirse con la Lic. Fátima Dávila en Procesos Técnicos del CUID, el día 28 de abril del año en curso. El importe será con cargo al POA 2026	08:00:00	17:00:00	Terrestre	\N	\N	\N	4008000 (0121) 2.06.PRDI506.PYI006	½ x $1,078.69 = $1,078.69	0.00	140.00	300.00	0.00	440.00	0.00	0.00	Nacional	2026-04-20	98	2026	\N	f				Patricia Ruiz
29	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	T	2026-04-28	2026-04-28	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, para trasladar personal para entregar documentos en Ciudad Universitaria y Rectoría de la UNICACH. El importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	0.00	0.00	300.00	0.00	300.00	0.00	0.00	Nacional	2026-04-14	85	2026	\N	f				\N
33	C.P. YENNY REYES ROQUE	Tuxtla Gutiérrez, Chiapas	2026-02-24	2026-02-24	Borrador	RERY8005134G0	JEFE DE OFICINA "A"	CESMECA	Viajó a la ciudad de Tuxtla Gutiérrez, Chiapas, para realizar la entrega de documentos de los Posgrados en Estudios e Intervención Feministas, en el Departamento de Servicios Escolares y en la Dirección de Investigación y Posgrado de la UNICACH .	08:00:00	18:30:00	Terrestre	\N	\N	\N	4008020 0121 1.06.PRDI303.PYI003	½ x $1,078.69 = $1,078.69	0.00	140.00	0.00	0.00	140.00	0.00	0.00	Nacional	2026-02-19	61	2026	\N	f	23 de enero de 2026			\N
28	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-04-21	2026-04-21	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, para trasladar personal para entregar documentos en Ciudad Universitaria y Rectoría de la UNICACH. El importe será con cargo al POA 2026	08:00:00	18:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	0.00	0.00	300.00	0.00	300.00	0.00	0.00	Nacional	2026-04-14	84	2026	\N	f				\N
30	C.P. PATRICIA RUIZ PÉREZ	Tuxtla Gutiérrez, Chiapas	2026-04-28	2026-04-28	Borrador	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria y Rectoría de la UNICACH, para realizar trámites administrativos y la entrega de valija. El importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008000 (0121) 2.06.PRDI1029.PYI029	½ x $970.82 = $970.82	800.00	0.00	300.00	210.00	1310.00	0.00	0.00	Nacional	2026-04-14	86	2026	\N	f				\N
9	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-03-04	2026-03-04	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1034.PYI034	1 x $900.00 = $900.00	2000.00	0.00	450.00	200.00	2650.00	0.00	0.00	Nacional	2026-03-03	9	2026	\N	f	\N	\N	\N	Dora Gordillo
10	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez, Chiapas	2026-03-12	2026-03-12	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029, 4008000 (0121) 2.06.PRDI202.PYI002	1 x $900.00 = $900.00	2000.00	0.00	450.00	200.00	2650.00	0.00	0.00	Nacional	2026-03-12	10	2026	\N	f	\N	\N	\N	Dora Gordillo
31	C.P. YENNY REYES ROQUE	Tuxtla Gutiérrez, Chiapas	2026-01-23	2026-01-23	Borrador	RERY8005134G0	JEFE DE OFICINA "A"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas, para realizar la entrega del acta de examen de grado de Anahí Vázquez Pérez, en el Departamento de Servicios Escolares de la UNICACH .	08:00:00	18:00:00	Terrestre	\N	\N	\N	4008020 0121 1.06.PRDI303.PYI003	½ x $1,078.69 = $1,078.69	0.00	140.00	0.00	0.00	140.00	0.00	0.00	Nacional	2026-01-22	15	2026	\N	f	23 de enero de 2026			\N
32	C.P. YENNY REYES ROQUE	Tuxtla Gutiérrez, Chiapas	2026-02-13	2026-02-13	Borrador	RERY8005134G0	JEFE DE OFICINA "A"	CESMECA	Viajó a la ciudad de Tuxtla Gutiérrez, Chiapas, para realizar la entrega de expedientes de nuevo ingreso de los Posgrados en Estudios e Intervención Feministas, en el Departamento de Servicios Escolares de la UNICACH .	08:00:00	18:00:00	Terrestre	\N	\N	\N	4008020 0121 1.06.PRDI303.PYI003, 4008010 0121 1.06.PRDI506.PYI006	½ x $1,078.69 = $1,078.69	0.00	140.00	202.00	0.00	342.00	0.00	0.00	Nacional	2026-02-12	40	2026	\N	f	23 de enero de 2026			\N
46	DR. EMMANUEL NÁJERA DE LEÓN	Tuxtla Gutiérrez, Chiapas	2026-04-23	2026-04-23	Borrador	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas  con el objetivo de asistir a una reunión de trabajo el día 23 de abril del presente año, a las 10:00 horas la reunión se llevará a cabo en la sala de capacitación del CONOCER, ubicada en el edificio de la Unidad de Investigación Multidisciplinaria de Ciudad Universitaria de la UNICACH.	08:30:00	16:30:00	Terrestre	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-04-21	99	2026	\N	f				Dora Gordillo
23	DR. EMMANUEL NÁJERA DE LEÓN	Tuxtla Gutiérrez, Chiapas	2026-03-03	2026-03-03	Borrador	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, Chiapas, para asistir a una reunión de trabajo para dar seguimiento y tratar asuntos inherentes a los Posgrados, en la sala Mauro Moreno Corzo en CU de la UNICACH y para realizar el seguimiento Institucional del CESMECA, en Rectoría, secretarias y Departamentos de la UNICACH.	08:00:00	16:00:00	Terrestre	Honda	CRV	DNG-272-J	4008000 (0121) 2.06.PRDI1029.PYI029, 4008010 0121 1.04.PRDI106.PYI006	½ x $1,510.16 = $1,510.16	3194.04	0.00	0.00	1200.00	4394.04	0.00	0.00	Nacional	2026-02-03	20	2026	\N	t	03, 05, 06, 09, 11, 13, 16, 18, 19, 20 febrero 2026.	03 de febrero 2026 8:30am\n05 de febrero 2026 8:30am\n06 de febrero 2026 8:30am\n09 de febrero 2026 8:30am\n11 de febrero 2026 8:30am\n13 de febrero 2026 8:30am\n16 de febrero 2026 8:30am\n18 de febrero 2026 8:30am\n19 de febrero 2026 8:30am\n20 de febrero 2026 8:30am	03 de febrero 2026 6:00pm\n05 de febrero 2026 6:00pm\n06 de febrero 2026 6:00pm\n09 de febrero 2026 6:00pm\n11 de febrero 2026 6:00pm\n13 de febrero 2026 6:00pm\n16 de febrero 2026 6:00pm\n18 de febrero 2026 6:00pm\n19 de febrero 2026 6:00pm\n20 de febrero 2026 6:00pm	\N
40	C.P. YENNY REYES ROQUE	Tuxtla Gutiérrez, Chiapas	2026-04-17	2026-04-17	Borrador	RERY8005134G0	JEFE DE OFICINA "A" 1	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, con el propósito de asistir a reuniones y atender asuntos relacionados con los programas de Posgrado, en las oficinas de Investigación y Posgrado, y posteriormente en el área de Servicios Escolares de Ciudad Universitaria de la UNICACH.	08:00:00	17:00:00	Terrestre	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-04-16	93	2026	\N	f				\N
35	C.P. PATRICIA BALLINAS SALAZAR	Tuxtla Gutiérrez Chiapas	2026-05-05	2026-05-05	Borrador	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria de la UNICACH y Rectoría de la UNICACH, para realizar tramites administrativos  y entrega de valija. El importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008010 0121 1.04.PRDI106.PYI006 	½ x $970.82 = $970.82	800.00	0.00	300.00	210.00	1310.00	0.00	0.00	Nacional	2026-04-16	88	2026	\N	f				\N
36	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez Chiapas	\N	\N	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez Chiapas para trasladar personal para entregar documentos en Ciudad Universitaria y Rectoría de la UNICACH.	\N	\N	Terrestre	Chevrolet	Colorado	CY-2995-H	4008010 0121 1.04.PRDI106.PYI006 	½ x $970.82 = $970.82	0.00	0.00	600.00	0.00	600.00	0.00	0.00	Nacional	2026-04-16	89	2026	\N	t	05 y 08 de mayo de 2026	05 de mayo de 2026 8:00am\n08 de mayo de 2026 8:00am	05 de mayo de 2026 6:00pm\n08 de mayo de 2026 6:00pm	\N
37	C.P. PATRICIA BALLINAS SALAZAR	Tuxtla Gutiérrez Chiapas	2026-05-05	2026-05-05	Borrador	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria de la UNICACH y Rectoría de la UNICACH, para realizar tramites administrativos  y entrega de valija. El importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008010 0121 1.04.PRDI106.PYI006 	½ x $970.82 = $970.82	1600.00	0.00	600.00	420.00	2620.00	0.00	0.00	Nacional	2026-04-16	90	2026	\N	t	12 y 14 de mayo de 2026	12 de mayo de 2026 8:00 am\n14 de mayo de 2026 8:00 am	12 de mayo de 2026 6:00 pm\n14 de mayo de 2026 6:00 pm	\N
38	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	Tuxtla Gutiérrez Chiapas	\N	\N	Borrador	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez Chiapas para trasladar personal para entregar documentos en Ciudad Universitaria y Rectoría de la UNICACH.	\N	\N	Terrestre	Chevrolet	Colorado	CY-2995-H	4008010 0121 1.04.PRDI106.PYI006 	½ x $970.82 = $970.82	0.00	0.00	600.00	0.00	600.00	0.00	0.00	Nacional	2026-04-16	91	2026	\N	t	12 y 14 de mayo de 2026	12 de mayo de 2026 8:00am\n14 de mayo de 2026 8:00am	12 de mayo de 2026 6:00pm\n14 de mayo de 2026 6:00pm	\N
39	C.P. PATRICIA RUIZ PÉREZ	Tuxtla Gutiérrez, Chiapas	2026-05-08	2026-05-08	Borrador	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA	Viajar la Ciudad de Tuxtla Gutiérrez, Chiapas, a las oficinas de Ciudad Universitaria y Rectoría de la UNICACH, para realizar trámites administrativos y la entrega de valija. El importe será con cargo al POA 2026.	08:00:00	18:00:00	Terrestre	Chevrolet	Colorado	CY-2995-H	4008010 0121 1.04.PRDI106.PYI006	½ x $970.82 = $970.82	800.00	0.00	300.00	210.00	1310.00	0.00	0.00	Nacional	2026-04-16	92	2026	\N	f				\N
41	MTRA. YESENIA LÓPEZ CRUZ	Tuxtla Gutiérrez, Chiapas	2026-04-17	2026-04-17	Borrador	LOCY871111RE3	SECRETARIA ACADEMICA DE INSTITUTO "B"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, con el propósito de asistir a reuniones y atender asuntos relacionados con los programas de Posgrado, en las oficinas de Investigación y Posgrado, y posteriormente en el área de Servicios Escolares de Ciudad Universitaria de la Unicach.	08:00:00	17:00:00	Terrestre	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-04-16	94	2026	\N	f				\N
34	 DRA. DELMY TANIA CRUZ HERNÁNDEZ	 VASCO,ESPAÑA. 	2026-05-18	2026-05-26	Borrador	CUHD820723MTA	PROFESOR INVESTIGADOR DE TC TITULAR  "A"	CESMECA	Viajar al Pais Vasco, España para participar como ponente  en el "XV  Congreso Internacional " Mundos de Mujeres 2026, Mujeres* y Pazes" en Gernika y Bilboa  invitada por el Centro de Investigación por la paz  Gernika Geoguratuz  (Pais Vasco, España)  y la ONGD  Gernikatik Mundura  que se realizará del 20 al 25 de mayo del presente año 	\N	\N	Aéreo	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Internacional	2026-04-15	87	2026	\N	f				\N
43	MTRA. NORMA GUADALUPE PÉREZ LÓPEZ	Tuxtla Gutiérrez, Chiapas	2026-02-17	2026-02-17	Borrador	PELN800901569	COORDINADOR ACADÉMICO "B"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, para participar en la Jornada de Tequios en espacios deportivos, actividad orientada a fortalecer la colaboración, la solidaridad y la cohesión comunitaria mediante el trabajo colectivo, voluntario y no remunerado en beneficio de la vida universitaria, en las oficias de Ciudad Universitaria de la UNICACH.	08:00:00	18:00:00	Terrestre	\N	\N	\N	4008020 0121 1.06.PRDI303.PYI003	½ x $1,510.16 = $1,510.16	0.00	152.00	0.00	0.00	152.00	0.00	0.00	Nacional	2026-02-13	42	2026	\N	f				Patricia Ballinas
44	MTRA. NORMA GUADALUPE PÉREZ LÓPEZ	Tuxtla Gutiérrez, Chiapas	2026-02-20	2026-02-20	Borrador	PELN800901569	COORDINADOR ACADÉMICO "B"	CESMECA	Viajar a la ciudad de Tuxtla Gutiérrez, para participar en una reunión de trabajo para la revisión de las plantillas académicas y planes de estudio de los Posgrados en Feminismos, en las oficias de Ciudad Universitaria de la UNICACH.	08:00:00	18:00:00	Terrestre	\N	\N	\N	4008020 0121 1.06.PRDI303.PYI003	½ x $1,510.16 = $1,510.16	0.00	140.00	0.00	0.00	140.00	0.00	0.00	Nacional	2026-02-19	58	2026	\N	f				Patricia Ballinas
47	MTRA. YESENIA LÓPEZ CRUZ	Tuxtla Gutiérrez, Chiapas	2026-04-22	2026-04-22	Borrador	LOCY871111RE3	SECRETARIA ACADEMICA DE INSTITUTO "B"	CESMECA	viajar a la Ciudad de Tuxtla Gutierrez Chiapas, con el objetivo de asistir a una reunión de trabajo con la Rectora, que se llevará a cabo el día 22 de abril del presente año, a las 08:45 horas, la reunión tendrá lugar en la sala de juntas de Rectoría de Ciudad Universitaria de la UNICACH.	08:00:00	17:00:00	Terrestre	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	Nacional	2026-04-21	100	2026	\N	f				Dora Gordillo
\.


--
-- Data for Name: personal; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.personal (id, nombre, rfc, categoria, adscripcion) FROM stdin;
1	MTRA. NORMA GUADALUPE PÉREZ LÓPEZ	PELN800901569	COORDINADOR ACADÉMICO "B"	CESMECA
2	MTRA. GABRIELA CARTAGENA LÓPEZ	CAL880703	COORDINADOR ACADÉMICO "C"	CESMECA
3	LIC. JENNY ARACELI MOLINA GOMEZ	MOGJ801228AU0	SECRETARIO ADMINISTRATIVO DE INSTITUTO "A"	CESMECA
4	C.P. YENNY REYES ROQUE	RERY8005134G0	JEFE DE OFICINA "A"	CESMECA
5	MTRA. YESENIA LÓPEZ CRUZ	LOCY871111RE3	SECRETARIA ACADEMICA DE INSTITUTO "B"	CESMECA
6	MTRA. ADRIANA GUADALUPE RAMOS ZEPEDA	RAZA900305FL2	JEFE DE OFICINA "B"	CESMECA
7	DR. EMMANUEL NÁJERA DE LEÓN	NALE830718S8A	DIRECTOR CESMECA-UNICACH	CESMECA
8	LIC. GABRIELA FRAGOSO SAMANIEGO	FASG651225TJ2	JEFE DE OFICINA "A"	CESMECA
9	LIC. ROBERTO RICO CHONG	RICR600524I34	SECRETARIO DE EXTENSIÓN Y VINCULACIÓN "A"	CESMECA
10	C.P. PATRICIA BALLINAS SALAZAR	BASP690317D33	JEFE DE SECCIÓN "B"	CESMECA
11	C.P. PATRICIA RUIZ PÉREZ	RUPP760620AW5	JEFE DE SECCION "C"	CESMECA
13	LIC. JUAN JESÚS PÉREZ GÓMEZ	PEGJ820128NXA	TECNICO ACADEMICO ASOCIADO "C"	CESMECA
14	LIC. OLGA PATRICIA DE LA CRUZ GONZALEZ	CUAO961108HE3	JEFE DE OFICINA "A"	CESMECA
15	C. ARMANDO DE JESÚS ARGÜELLO BAUTISTA	AUBA731101-113	ADMINISTRATIVO CALIFICADO "A"	CESMECA
16	C. MARIELY JANETH NAVA GENOVÉS	NAGM9907304VA	INTENDENTE "C"	CESMECA
17	C. YANETH MERA CALVA	MECA870122-JD3	ADMINISTRATIVO "B"	CESMECA
18	ROBERTO ANTONIO MÉNDEZ GARCÍA	MEGR8406119S0	TECNICO EN MANTENIMIENTO "A"	CESMECA
19	C. BRENDA KARINA MEDINA VILLAFUERTE	MEVB8404031K1	AUXILIAR ADMINISTRATIVO "A"	CESMECA
20	C. MELESIO VALENTÍN MÉNDEZ GARCÍA	MEGM860212PB5	INTENDENTE "A"	CESMECA
21	C. DORA JUVENALIA GORDILLO ESTRADA	GOED721218S25	TECNICO ESPECIALIZADO "C"	CESMECA
22	C. IRMA CECILIA MEDINA VILLAFUERTE	MEVI7307023E6	ADMINISTRATIVO CALIFICADO "A"	CESMECA
24	ROBERTO CARLOS HOOVER SILVANO	HOSR760103LR7	TECNICO ACADEMICO	CESMECA
25	C. SAMUEL DE JESÚS GÓMEZ GONZÁLEZ	GGSJ801220TNA	JEFE DE SECCIÓN "A"	CESMECA
12	LIC. EGNER VAZQUEZ LÓPEZ	VALE870125AI7	TECNICO ACADEMICO ASOCIADO "C"	CESMECA
30	GUADALUPE GONZÁLEZ PALE	GOPG660415R85	JEFE DE SECCIÓN "B"	CESMECA
31	ANA MARÍA DE LA CRUZ GONZÁLEZ	CUGA900417HJ3	JEFE DE OFICINA "A"	CESMECA
32	SAMUEL DE JESÚS GÓMEZ GONZÁLEZ	GOGS801220TNA	JEFE SECCIÓN "A"	CESMECA
35	MARÍA DEL CARMEN GARCÍA AGUILAR	GAAC560716BA6	INVESTIGADOR DE TC. TITULAR "C"	CESMECA
37	MARÍA DE LOURDES MORALES VARGAS	MOVL811117IL5	PROFESOR INVESTIGADOR DE TC. ASOCIADO "B"	CESMECA
38	ROBERTO CARLOS HOOVER SILVANO	HOSR760103LR7	TÉCNICO ACADÉMICO TITULAR "A"	CESMECA
40	MAGDA ESTRELLA ZÚÑIGA ZENTENO	ZUZM660702P91	INVESTIGADOR DE TC: TITULAR "C"	CESMECA
39	DR. RAÚL ARRIAGA ORTIZ	AIOR760719NL4	PROFESOR INVESTIGADOR DE TC. TITULAR "A"	CESMECA
33	DRA. FLOR MARINA BERMÚDEZ URBINA	BEUF790118S43	INVESTIGADOR DE TC: TITULAR "C"	CESMECA
41	ING. LUIS GERARDO MORALES RAMOS	MORL730406FM3	JEFE DE SECCION "C"	CESMECA
36	LIC. IDOLINA GUZMÁN CORONADO	GUCI771224HPO	TÉCNICO ACADÉMICO TITULAR "C"	CESMECA
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.usuarios (id, username, password, nombre, rol, activo) FROM stdin;
1	jmolina	cesmeca2026	Jenny Molina	Administradora	t
2	pballinas	cesmeca2026	Patricia Ballinas	Auxiliar	t
3	pruiz	cesmeca2026	Patricia Ruiz	Auxiliar	t
4	dgordillo	cesmeca2026	Dora Gordillo	Auxiliar	t
5	odelacruz	cesmeca2026	Olga Patricia De La Cruz González	Auxiliar	t
6	admin	admin123	Roberto (Super Admin)	Administrador	t
\.


--
-- Data for Name: vehiculos; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.vehiculos (id, marca, modelo, placas) FROM stdin;
1	Chevrolet	Colorado	CY-2995-H
2	Honda	CRV	DNG-272-J
3	Toyota	Yaris	DNG-273-J
\.


--
-- Name: autoridades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.autoridades_id_seq', 6, true);


--
-- Name: bitacora_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.bitacora_id_seq', 168, true);


--
-- Name: claves_presupuestales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.claves_presupuestales_id_seq', 6, true);


--
-- Name: claves_programaticas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.claves_programaticas_id_seq', 17, true);


--
-- Name: ordenes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.ordenes_id_seq', 47, true);


--
-- Name: personal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.personal_id_seq', 41, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 6, true);


--
-- Name: vehiculos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.vehiculos_id_seq', 3, true);


--
-- Name: autoridades autoridades_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.autoridades
    ADD CONSTRAINT autoridades_pkey PRIMARY KEY (id);


--
-- Name: autoridades autoridades_rol_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.autoridades
    ADD CONSTRAINT autoridades_rol_key UNIQUE (rol);


--
-- Name: bitacora bitacora_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.bitacora
    ADD CONSTRAINT bitacora_pkey PRIMARY KEY (id);


--
-- Name: claves_presupuestales claves_presupuestales_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.claves_presupuestales
    ADD CONSTRAINT claves_presupuestales_pkey PRIMARY KEY (id);


--
-- Name: claves_programaticas claves_programaticas_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.claves_programaticas
    ADD CONSTRAINT claves_programaticas_pkey PRIMARY KEY (id);


--
-- Name: ordenes ordenes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ordenes
    ADD CONSTRAINT ordenes_pkey PRIMARY KEY (id);


--
-- Name: personal personal_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.personal
    ADD CONSTRAINT personal_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_username_key UNIQUE (username);


--
-- Name: vehiculos vehiculos_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehiculos
    ADD CONSTRAINT vehiculos_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict ffrBEb0sQ8W5ItXPcNtMSqBD218cgg6ys321rBvX9BTi5w88Jf9mFretCC12HmM

